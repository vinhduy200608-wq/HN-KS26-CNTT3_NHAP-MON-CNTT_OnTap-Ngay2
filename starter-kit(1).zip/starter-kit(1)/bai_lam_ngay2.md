# BÀI LÀM – ÔN TẬP NGÀY 2
-   **Họ tên:**  NGUYỄN CÔNG VINH
-   **Lớp:**  HN_K26-CNTT3
-   **Link repository:**  https://github.com/vinhduy200608-wq/HN-KS26-CNTT3_NHAP-MON-CNTT_OnTap-Ngay2.git
-   **Hệ điều hành (Windows/macOS):**  MacOs

## Bài 1. Lọc log thủ công
### Lệnh đã chạy
```
cat logs/access.log
grep "ERROR" logs/access.log > logs/error_report.txt
cat logs/error_report.txt
```
### 2 dòng lỗi đầu tiên trong error_report.txt
```
2025-10-18 08:17:59 [ERROR] Khong tim thay trang /lich-thi (404)
2025-10-18 08:25:55 [ERROR] Het thoi gian cho (timeout)

```

## Bài 2. Đếm bằng pipeline
### Lệnh
```
cat logs/access.log | grep "WARNING" | wc -l
cat logs/payment.log | grep "ERROR" | wc -l
```
### Kết quả đếm (Windows: giá trị Count; macOS: con số in ra)

```
WARNING trong access.log: 4
ERROR trong payment.log: 3

```

## Bài 3. Chạy script auto_warning (.ps1 hoặc .sh)

### Lệnh chạy
```
bash auto_warning.sh
```
### Nội dung file logs/warning_report.txt
```
=== CANH BAO THANH TOAN ===
2025-10-18 09:19:13 [WARNING] Cong thanh toan phan hoi cham
2025-10-18 09:28:16 [WARNING] Nhieu lan nhap sai ma OTP
2025-10-18 09:43:01 [WARNING] So du vi gan bang hoc phi
2025-10-18 09:46:22 [WARNING] So du vi gan bang hoc phi
2025-10-18 09:49:43 [WARNING] So du vi gan bang hoc phi

```

## Bài 4. Báo cáo tổng hợp
### Các lệnh đã chạy

echo "=== TONG HOP ACCESS LOG ===" > logs/tong_hop_ngay2.txt
cat logs/access.log | grep "ERROR" >> logs/tong_hop_ngay2.txt
cat logs/payment.log | grep "WARNING" | wc -l >> logs/tong_hop_ngay2.txt

### Nội dung file logs/tong_hop_ngay2.txt

```
=== TONG HOP ACCESS LOG ===
2025-10-18 08:17:59 [ERROR] Khong tim thay trang /lich-thi (404)
2025-10-18 08:25:55 [ERROR] Het thoi gian cho (timeout)
2025-10-18 08:33:51 [ERROR] Ket noi may chu du lieu that bai
2025-10-18 08:37:19 [ERROR] Ket noi may chu du lieu that bai
2025-10-18 08:49:43 [ERROR] Het thoi gian cho (timeout)
2025-10-18 08:53:11 [ERROR] Het thoi gian cho (timeout)

```

## Bài 5. Câu hỏi ngắn

-   **a)**

> (Ghi đè)
Tạo File mới (nếu chưa có) hoặc xoá nội dung cũ rồi ghi nội dung mới.

>> (Ghi nối)
Giữ nguyên nội dung cũ và thèm nội dung mới vào cuối File.

-   **b)**  Nếu lệnh thứ hai dùng > thì dòng === TONG HOP ACCESS LOG === sẽ bị xoá, chỉ còn các dòng ERROR. Kết quả:

```
2025-10-18 08:17:59 [ERROR] Khong tim thay trang /lich-thi (404)
2025-10-18 08:25:55 [ERROR] Het thoi gian cho (timeout)
2025-10-18 08:33:51 [ERROR] Ket noi may chu du lieu that bai
2025-10-18 08:37:19 [ERROR] Ket noi may chu du lieu that bai
2025-10-18 08:49:43 [ERROR] Het thoi gian cho (timeout)
2025-10-18 08:53:11 [ERROR] Het thoi gian cho (timeout)

```

-   **c)**  Trong script nên dùng đường dẫn tương đối logs/payment.log thay vì đường dẫn tuyệt đối trên máy mình vì Relative Path chỉ phụ thuộc vào vị trí của thư mục nên script vẫn chạy được khi gửi qua máy khác trong khi Absolute Path phụ thuộc vào ổ đĩa trên máy tính cá nhân nên script sẽ không chạy được khi chia sẻ qua máy khác.

## Tự chấm (điền sau khi có đáp án)

-   **Điểm tự chấm:**  ..../100
-   **Lỗi mình đã mắc và cách sửa:**